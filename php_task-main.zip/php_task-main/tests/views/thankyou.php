<?php 

echo "THANK YOU";

?>