<?php
 require_once('vendor/stripe/stripe-php/init.php');
 require 'lib/redbean/rb-mysql.php';
 use RedBeanPHP\Facade as R;
 R::setup("mysql: host=localhost;dbname=eshop", "root", "");
// require('config.php');
 $token = $_POST['stripeToken'];
 $email = $_POST['stripeEmail'];
 $productID = $id;
 $products = R::getAll("select * from products where id = $productID");



 $stripe = new \Stripe\StripeClient('sk_test_51GuJUHEWIKxG0jQGipoLydXlOInn5TTVhlzENqeEWko1O4Mp8yx6xCCO5urD7clz3CY0vg1Ar2VNOD81jSQ1YCct00WIysfCOy');
//  $customer = $stripe->customers->create([
//      'description' => 'example customer',
//      'email' => 'email@example.com',
//      'payment_method' => 'pm_card_visa',
//  ]);
 
 $charge = $stripe->charges->create([
     'amount' => $products[0]['price'] * 100,
     'currency' => 'usd',
     'source' => $token,
     'description' => $products[0]['description'],
   ]);

 if($charge['status']=="succeeded")
 {  ?>

<H1>THANK YOU FOR PURCHASING</H1>
<table class="table">

    <tr>
      <th scope="col">Product Title</th>
      <th scope="col">Price</th>
      <th scope="col">Payment Method</th>
   
    </tr>
  <tr>
    <td><?php echo $products[0]['title']; ?></td>
    <td><?php echo $products[0]['price']; ?></td>
    <td><?php echo "CARD" ?></td>
   <tr>
</table>



 <?php }
 ?>