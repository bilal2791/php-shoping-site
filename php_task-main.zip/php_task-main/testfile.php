<style>
    body {
    margin: 0;
    font-family: Roboto, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
    font-size: .8125rem;
    font-weight: 400;
    line-height: 1.5385;
    color: #333;
    text-align: left;
    background-color: #f5f5f5
}

.mt-50 {
    margin-top: 50px
}

.mb-50 {
    margin-bottom: 50px
}

.bg-teal-400 {
    background-color: #26a69a
}

a {
    text-decoration: none !important
}

.fa {
    color: red
}
</style>

<?php
require 'lib/redbean/rb-mysql.php';
use RedBeanPHP\Facade as R;
R::setup("mysql: host=localhost;dbname=eshop", "root", "");

// $db = R::dispense('products');
// $db->title ="test";
// $db->description ="lorem ispum donar";
// $db->image = "product.png";
// $db->price = "200";
// R::store($db);

$products = R::getAll("select * from products");
// echo "<pre>";
// print_r($products);
// echo "<pre>";
require('config.php');
?>



<form action="submit.php" method="post">
<script 
src="https://checkout.stripe.com/checkout.js" class="stripe-button"
data-key="<?php echo $publishedKey ?>"
data-amount="500"
data-name="programming with bilal"
data-description= "Description:"
data-image="iamge.png"
data-currency="pkr"
data-email="phpvbilal@gmail.com"
>

</script>
</form>