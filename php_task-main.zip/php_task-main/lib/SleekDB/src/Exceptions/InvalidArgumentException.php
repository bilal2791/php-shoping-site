<?php

namespace SleekDB\Exceptions;

class InvalidArgumentException extends \Exception
{
}
