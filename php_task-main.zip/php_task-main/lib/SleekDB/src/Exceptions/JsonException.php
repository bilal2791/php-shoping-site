<?php

namespace SleekDB\Exceptions;

class JsonException extends \Exception
{
}
